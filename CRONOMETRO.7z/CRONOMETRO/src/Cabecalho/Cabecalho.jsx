// src/cabecalho/Cabecalho.js
import React from 'react';
import './Cabecalho.css';

function Cabecalho() {
    return (
        <header className="header">
            <div className="top-section">
                <div className="left-section">
                { <img src="Logo.png" alt="" className='my' /> }
                    <h1 className="title">MyPeace</h1>
                </div>
                <nav className="right-section">
                    <ul>
                        <li><a href="#">Perfil</a></li>
                        <li><a href="#">Home</a></li>
                    </ul>
                </nav>
            </div>
            <div className="bottom-bar">
                Respiração Guiada
            </div>
        </header>
    );
}

export default Cabecalho;
