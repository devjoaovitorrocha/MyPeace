import { useState } from 'react'
import './App.css'
import Cabecalho from './Cabecalho/Cabecalho'
import Conteudo from './Conteudo/Conteudo'
import Rodape from './Rodape/Rodape'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <Cabecalho/>
      <Conteudo/>
      <Rodape/>
    </>
  )
}
export default App
