import React from 'react';
import './Cabecalho.css';

function Cabecalho() {
    return (
        <header className="header">
            <div className="top-section">
                <div className="left-section">
                { <img src="Logo.png" alt="" className='my' /> }
                    <h1 className="title">MyPeace</h1>
                </div>
                <nav className="right-section">
                    <ul>
                        <li><a href="#">Voltar</a></li>
                       
                    </ul>
                </nav>
            </div>
            
        </header>
    )
}

export default Cabecalho;