import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Cabecalho from './Cabecalho/Cabecalho'
import Conteudo from './Conteudo/Conteudo'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <Cabecalho/>
      <Conteudo/>
  
    </>
  )
}

export default App
