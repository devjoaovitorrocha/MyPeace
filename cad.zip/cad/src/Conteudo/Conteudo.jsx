import React, { useState } from "react";
import "./Conteudo.css";

function Conteudo() {
  const [formData, setFormData] = useState({
    firstname: "",
    lastname: "",
    email: "",
    number: "",
    password: "",
    confirmPassword: "",
    gender: ""
  });

  const [showPopup, setShowPopup] = useState(false);
  const [emailValue, setEmailValue] = useState("");
  const [codeValue, setCodeValue] = useState("");

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submission logic here
    setShowPopup(true); // Mostrar o popup ao enviar o formulário
  };

  const closePopup = () => {
    setShowPopup(false); // Função para fechar o popup
  };

  const handleEmailChange = (e) => {
    setEmailValue(e.target.value);
  };

  const handleCodeChange = (e) => {
    setCodeValue(e.target.value);
  };

  const handleConfirmEmail = () => {
    // Aqui você pode adicionar a lógica para confirmar o e-mail e o código
    console.log("E-mail:", emailValue);
    console.log("Código:", codeValue);
    // Fechar o popup após confirmar
    setShowPopup(false);
  };

  return (
    <div className="container">
      <div className="form">
        <form onSubmit={handleSubmit}>
          <div className="form-header">
            <div className="title">
              <h1>Cadastre-se</h1>
            </div>
            <div className="login-button">
              <button type="submit">Continuar</button>
            </div>
          </div>

          <div className="input-group">
            <div className="input-box">
              <label htmlFor="firstname">Primeiro Nome</label>
              <input
                id="firstname"
                type="text"
                name="firstname"
                placeholder="Digite seu primeiro nome"
                value={formData.firstname}
                onChange={handleChange}
                required
              />
            </div>

            <div className="input-box">
              <label htmlFor="lastname">Sobrenome</label>
              <input
                id="lastname"
                type="text"
                name="lastname"
                placeholder="Digite seu sobrenome"
                value={formData.lastname}
                onChange={handleChange}
                required
              />
            </div>
            <div className="input-box">
              <label htmlFor="email">E-mail</label>
              <input
                id="email"
                type="email"
                name="email"
                placeholder="Digite seu e-mail"
                value={formData.email}
                onChange={handleChange}
                required
              />
            </div>

            <div className="input-box">
              <label htmlFor="number">Celular</label>
              <input
                id="number"
                type="tel"
                name="number"
                placeholder="(xx) xxxx-xxxx"
                value={formData.number}
                onChange={handleChange}
                required
              />
            </div>

            <div className="input-box">
              <label htmlFor="password">Senha</label>
              <input
                id="password"
                type="password"
                name="password"
                placeholder="Digite sua senha"
                value={formData.password}
                onChange={handleChange}
                required
              />
            </div>

            <div className="input-box">
              <label htmlFor="confirmPassword">Confirme sua Senha</label>
              <input
                id="confirmPassword"
                type="password"
                name="confirmPassword"
                placeholder="Digite sua senha novamente"
                value={formData.confirmPassword}
                onChange={handleChange}
                required
              />
            </div>
          </div>

          <div className="gender-inputs">
            <div className="gender-title">
              <h6>Gênero</h6>
            </div>

            <div className="gender-group">
              <div className="gender-input">
                <input
                  id="female"
                  type="radio"
                  name="gender"
                  value="female"
                  onChange={handleChange}
                />
                <label htmlFor="female">Feminino</label>
              </div>

              <div className="gender-input">
                <input
                  id="male"
                  type="radio"
                  name="gender"
                  value="male"
                  onChange={handleChange}
                />
                <label htmlFor="male">Masculino</label>
              </div>

              <div className="gender-input">
                <input
                  id="others"
                  type="radio"
                  name="gender"
                  value="others"
                  onChange={handleChange}
                />
                <label htmlFor="others">Outros</label>
              </div>

              <div className="gender-input">
                <input
                  id="none"
                  type="radio"
                  name="gender"
                  value="preferNotToSay"
                  onChange={handleChange}
                />
                <label htmlFor="none">Prefiro não dizer</label>
              </div>
            </div>
          </div>
        </form>
      </div>

      {/* Popup de Confirmação */}
      {showPopup && (
        <div className="popup">
          <div className="popup-content">
            <span className="close" onClick={closePopup}>&times;</span>
            <h2>Confirme seu E-mail e Insira o Código</h2>
            <input
              type="email"
              placeholder="Digite seu e-mail"
              value={emailValue}
              onChange={handleEmailChange}
              required
            />
            <input
              type="text"
              placeholder="Digite o código recebido"
              value={codeValue}
              onChange={handleCodeChange}
              required
            />
            <button onClick={handleConfirmEmail}>Enviar</button>
          </div>
        </div>
      )}
    </div>
  );
}

export default Conteudo;
